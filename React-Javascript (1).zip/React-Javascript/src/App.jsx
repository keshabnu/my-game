
import './App.css'
import Leaderboard from './Leaderboard'

export default function App() {
  return (
    <div className="app">
      <Leaderboard />
    </div>
  )
}
