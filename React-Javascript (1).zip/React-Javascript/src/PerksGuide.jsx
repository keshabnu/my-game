
import './PerksGuide.css'

const tierData = [
  {
    name: "Bronze",
    pointsRequired: "0 – 999 pts",
    color: "#CD7F32",
    icon: "🥉",
    perks: [
      "Starter Badge",
      "Basic access to community",
      "Monthly newsletter updates"
    ]
  },
  {
    name: "Silver",
    pointsRequired: "1000 – 1999 pts",
    color: "#C0C0C0",
    icon: "🥈",
    perks: [
      "Priority Signup",
      "Silver profile border",
      "Early access to events",
      "Community forum access"
    ]
  },
  {
    name: "Gold",
    pointsRequired: "2000 – 2999 pts",
    color: "#FFD700",
    icon: "🥇",
    perks: [
      "Community Spotlight feature",
      "Gold badge display",
      "Volunteer opportunity priority",
      "Monthly recognition"
    ]
  },
  {
    name: "Platinum",
    pointsRequired: "3000 – 4999 pts",
    color: "#E5E4E2",
    icon: "💎",
    perks: [
      "Leadership eligibility",
      "Platinum profile frame",
      "Event planning access",
      "Mentor program participation",
      "VIP community access"
    ]
  },
  {
    name: "God of Kindness",
    pointsRequired: "5000+ pts",
    color: "#2E7D32",
    icon: "👑",
    perks: [
      "Community Hero title",
      "Hall of Fame inclusion",
      "Special recognition frame",
      "Ambassador privileges",
      "Lifetime achievement status",
      "Direct impact on community decisions"
    ]
  }
]

function TierCard({ tier, isUnlocked, userPoints = 0 }) {
  const getPointsFromRange = (range) => {
    if (range.includes('+')) return parseInt(range.split('+')[0])
    return parseInt(range.split('–')[0])
  }

  const isCurrentTier = () => {
    if (tier.name === "God of Kindness") return userPoints >= 5000
    if (tier.name === "Platinum") return userPoints >= 3000 && userPoints < 5000
    if (tier.name === "Gold") return userPoints >= 2000 && userPoints < 3000
    if (tier.name === "Silver") return userPoints >= 1000 && userPoints < 2000
    if (tier.name === "Bronze") return userPoints >= 0 && userPoints < 1000
    return false
  }

  return (
    <div className={`tier-card ${isUnlocked ? 'unlocked' : 'locked'} ${isCurrentTier() ? 'current' : ''}`}>
      <div className="tier-header">
        <div className="tier-icon" style={{ color: isUnlocked ? tier.color : '#9E9E9E' }}>
          {tier.icon}
        </div>
        <div className="tier-info">
          <h3 className="tier-name" style={{ color: isUnlocked ? tier.color : '#9E9E9E' }}>
            {tier.name}
          </h3>
          <p className="tier-points">{tier.pointsRequired}</p>
        </div>
        <div className="tier-status">
          {isUnlocked ? (
            <span className="status-badge unlocked">✓ Unlocked</span>
          ) : (
            <span className="status-badge locked">🔒 Locked</span>
          )}
        </div>
      </div>
      <div className="tier-perks">
        <h4>Perks & Benefits:</h4>
        <ul>
          {tier.perks.map((perk, index) => (
            <li key={index}>{perk}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default function PerksGuide({ userPoints = 0, onBackToLeaderboard }) {
  const getUserTier = (points) => {
    if (points >= 5000) return "God of Kindness"
    if (points >= 3000) return "Platinum"
    if (points >= 2000) return "Gold"
    if (points >= 1000) return "Silver"
    return "Bronze"
  }

  const isUnlocked = (tierName) => {
    const userTier = getUserTier(userPoints)
    const tierOrder = ["Bronze", "Silver", "Gold", "Platinum", "God of Kindness"]
    const userTierIndex = tierOrder.indexOf(userTier)
    const currentTierIndex = tierOrder.indexOf(tierName)
    return currentTierIndex <= userTierIndex
  }

  return (
    <div className="perks-guide-container">
      <div className="perks-guide-card">
        <div className="perks-header">
          {onBackToLeaderboard && (
            <button className="back-button" onClick={onBackToLeaderboard}>
              ← Back to Leaderboard
            </button>
          )}
          <h1 className="perks-title">Perks Guide</h1>
          <p className="perks-subtitle">Unlock amazing benefits as you climb the eco ladder!</p>
        </div>
        
        <div className="current-status">
          <div className="status-info">
            <h3>Your Current Status</h3>
            <div className="current-tier">
              <span className="tier-badge" style={{ background: tierData.find(t => t.name === getUserTier(userPoints))?.color }}>
                {tierData.find(t => t.name === getUserTier(userPoints))?.icon} {getUserTier(userPoints)}
              </span>
              <span className="current-points">{userPoints.toLocaleString()} points</span>
            </div>
          </div>
        </div>

        <div className="tiers-timeline">
          {tierData.map((tier, index) => (
            <div key={tier.name} className="timeline-item">
              <div className="timeline-connector">
                {index < tierData.length - 1 && <div className="connector-line"></div>}
              </div>
              <TierCard 
                tier={tier} 
                isUnlocked={isUnlocked(tier.name)}
                userPoints={userPoints}
              />
            </div>
          ))}
        </div>
        
        <div className="guide-footer">
          <div className="motivation-text">
            <h3>Keep Growing Your Impact! 🌱</h3>
            <p>Every point brings you closer to unlocking amazing perks and making a bigger difference in your community.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
